<?php
//MySQL database connection information
$servername = "127.0.0.1";
$username = "root";
$password = "happynews";
$dbname = "julio_tables";

//connection snippets
//$conn = new mysqli($servername, $username, $password, $dbname);
//$conn->close();
?>
