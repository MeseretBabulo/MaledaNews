#Happy-News Project#
Happy news é um website de noticias simples, com a função de  criar, editar e deletar noticias após se cadastrar, é possivel visualizar elas na pagina principal e pesquisar noticias pelas suas tags.

Os dados para login no banco de dados estão no arquivo dblogin.php dentro da pasta stuff

O site é responsivo e deve funcionar corretamente em celulares ou telas menores

carregar o arquivo DB.sql para criar e alimentar o banco de dados com alguns dados exemplo.

login do usuario exemplo: Admin
senha do usuario exemplo: admin

caso não queira nenhum dados de exemplo apenas carregar a pagina BDConnect.php que esta na pasta stuff ira criar as tabelas (as informações do banco de dados devem estar atualizadas no arquivo dblogin.php nesse caso).
É possivel se registrar diretamente no site para criar postagens.
